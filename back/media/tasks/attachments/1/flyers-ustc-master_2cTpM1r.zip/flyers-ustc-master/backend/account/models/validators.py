from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _

def contact_email_qq_wechat(str):
    pass