from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _

# !TODO: score vailidators
def toefl_score(str):
    pass

def gre_score(str):
    pass

def enrolled_semester(str):
    pass