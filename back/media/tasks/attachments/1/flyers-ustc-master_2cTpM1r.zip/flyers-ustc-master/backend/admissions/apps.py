from django.apps import AppConfig


class AdmissionsConfig(AppConfig):
    name = 'admissions'
